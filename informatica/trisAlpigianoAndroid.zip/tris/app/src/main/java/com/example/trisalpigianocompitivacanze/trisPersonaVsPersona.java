package com.example.trisalpigianocompitivacanze;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

public class trisPersonaVsPersona extends AppCompatActivity {

    boolean vinto = false;
    public int[][] tris = {
            {0,0,0},
            {0,0,0},
            {0,0,0}
    };
    int turno = 1;
    int rimanenti = 9;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button reset = (Button) findViewById(R.id.btnReset);

        reset.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {

                EditText giocatore1  =(EditText)findViewById(R.id.giocatoreN1);
                EditText giocatore2  =(EditText)findViewById(R.id.giocatoreN2);
                giocatore1.getText().clear();
                giocatore2.getText().clear();

                for (int riga = 0;riga<3;riga++){
                    for (int colonna = 0;colonna<3;colonna++){
                        ((Button) findViewById(getResources().getIdentifier("btn"+String.valueOf(riga) + String.valueOf(colonna),"id", getPackageName()))).setText("-");
                    }
                }
                tris = new int[][]{
                        {0, 0, 0},
                        {0, 0, 0},
                        {0, 0, 0}
                };
                ((TextView) findViewById(R.id.lblRisultati)).setText("");
                rimanenti = 9;
                vinto = false;
                turno = 1;
            }

        });



    }
    public void cliccato(View v){
        int turnoPrec = turno;
        String giocatore1 = ((EditText)findViewById(R.id.giocatoreN1)).getText().toString();
        String giocatore2 = ((EditText)findViewById(R.id.giocatoreN2)).getText().toString();
        if (vinto)
                return;
        if(giocatore1.equals("") || giocatore1.equals("giocatore 1")|| giocatore1.equals("manca nome")){
            ((EditText)findViewById(R.id.giocatoreN1)).setText("manca nome");
            if(giocatore2.equals("") || giocatore2.equals("giocatore 2")|| giocatore2.equals("manca nome")) {
                ((EditText) findViewById(R.id.giocatoreN2)).setText("manca nome");
            }
            return;
        }
        if(giocatore2.equals("") || giocatore2.equals("giocatore 2")|| giocatore2.equals("manca nome")){
            ((EditText)findViewById(R.id.giocatoreN2)).setText("manca nome");
            return;
        }
        String nome = getResources().getResourceEntryName(v.getId());
        int x = Character.getNumericValue(nome.charAt(3));
        int y = Character.getNumericValue(nome.charAt(4));
        //System.out.println(x + " " + y +  " " + nome);
        if (tris[y][x] == 0){
            rimanenti--;
            //MainActivity.stampa(tris);
            tris[y][x] = turno;
            if(turno == 1){
                turno =2;
                ((Button)v).setText("X");
            }else{
                turno = 1;
                ((Button)v).setText("O");
            }
            //controlli:

            for (int riga = 0;riga<3;riga++){
                for (int colonna = 0;colonna<3;colonna++){
                    if(tris[riga][colonna]!=turnoPrec){
                        break;
                    }
                    if(colonna == 2){
                        System.out.println("vinto verticale");
                        vinto = true;
                    }
                }
            }
            for ( int colonna = 0;colonna<3;colonna++){
                for (int riga = 0;riga<3;riga++){
                    if(tris[riga][colonna]!=turnoPrec){
                        break;
                    }
                    if(riga == 2){
                        System.out.println("vinto orizzontale");
                        vinto = true;
                    }
                }
            }
            for (int diagonale = 0;diagonale<3;diagonale++){
                if(tris[diagonale][diagonale]!=turnoPrec){
                    break;
                }
                if(diagonale == 2){
                    System.out.println("vinto diagonale");
                    vinto = true;
                }
            }
            for (int diagonale = 0;diagonale<3;diagonale++){
                if(tris[diagonale][2-diagonale]!=turnoPrec){
                    break;
                }
                if(diagonale == 2){
                    System.out.println("vinto diagonale");
                    vinto = true;
                }
            }

            if(vinto){
                ((TextView) findViewById(R.id.lblRisultati)).setText("ha vinto\n" + ((EditText)findViewById(getResources().getIdentifier("giocatoreN"+turnoPrec,"id",getPackageName()))).getText().toString());
            }
            if(rimanenti == 0){
                ((TextView) findViewById(R.id.lblRisultati)).setText("PAREGGIO,\nricominciare la partita");
            }
        }
    }

    /*
    static void stampa(int[][] tris) {
        String stmp =  "";
        for (int riga = 0;riga<3;riga++){
            for (int colonna = 0;colonna<3;colonna++) {

                stmp = stmp + " " + tris[riga][colonna];
            }
            stmp = stmp + "\n";
        }
        System.out.println(stmp);
    }
    */
}
