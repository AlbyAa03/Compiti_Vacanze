package com.example.trisalpigianocompitivacanze;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class menuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_menu);


        Button PVP = (Button) findViewById(R.id.btnGiocatoreVsGiocatore);
        Button PVC = (Button) findViewById(R.id.btnGiocatoreVsComputer);
        PVC.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent2 = new Intent(menuActivity.this, trisPersonaVsCPU.class);
                startActivity(intent2);
            }
        });
        PVP.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                Intent intent2 = new Intent(menuActivity.this, trisPersonaVsPersona.class);
                startActivity(intent2);
            }
        });


    }
}